module.exports = {
    features: {
        categories: false,
        menu: false,
        tags: false
    }
};
