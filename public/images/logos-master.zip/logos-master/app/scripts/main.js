var React = require('react'),
    App  = require('./App');

document.addEventListener('DOMContentLoaded', function () {
    React.render(<App/>, document.getElementById('react'));
});
